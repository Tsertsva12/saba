﻿using ShopSystem.Models;

namespace ShopSystem.Services
{
    public class UserService
    {
        private readonly List<User> _users = new();

        public bool Register(string username, string password)
        {
            if (_users.Any(u => u.Username == username))
                return false;

            _users.Add(new User { Username = username, Password = password });
            return true;
        }

        public User? Login(string username, string password)
        {
            return _users.FirstOrDefault(u => u.Username == username && u.Password == password);
        }
    }
}
