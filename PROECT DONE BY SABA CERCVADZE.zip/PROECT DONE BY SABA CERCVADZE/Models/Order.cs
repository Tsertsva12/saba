﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopSystem.Models
{
    public class Order
    {
        public int Id { get; set; }
        public Customer Customer { get; set; }
        public List<Product> Products { get; set; } = new();
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public decimal TotalPrice => Products.Sum(p => p.Price);
    }
}
