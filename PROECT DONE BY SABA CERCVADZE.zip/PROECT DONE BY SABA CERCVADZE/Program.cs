﻿using ShopSystem.Models;
using ShopSystem.Services;

var productService = new ProductService();
var orderService = new OrderService();
var userService = new UserService();
User? loggedUser = null;


productService.AddProduct("bread", 1.50m, 100);
productService.AddProduct("milk", 3.20m, 50);
productService.AddProduct("fanta", 5.30m, 30);
productService.AddProduct("kola", 4.0m, 30);
productService.AddProduct("shawarma", 11.29m, 160);
productService.AddProduct("karaqi", 10.0m, 23);
productService.AddProduct("mwvadi shefutili", 2.80m, 75);
productService.AddProduct("parki", 0.30m, 100);

while (loggedUser == null)
{
    Console.WriteLine("\n======= LOGIN MENU =======");
    Console.WriteLine("1. Login");
    Console.WriteLine("2. Register");
    Console.WriteLine("0. Exit");

    Console.Write("Choose option: ");
    string input = Console.ReadLine()!;

    if (input == "1")
    {
        Console.Write("Username: ");
        string username = Console.ReadLine()!;
        Console.Write("Password: ");
        string password = Console.ReadLine()!;

        var user = userService.Login(username, password);

        if (user == null)
            Console.WriteLine(" Wrong username or password!");
        else
        {
            loggedUser = user;
            Console.WriteLine($" Welcome, {loggedUser.Username}!");
        }
    }
    else if (input == "2")
    {
        Console.Write("New username: ");
        string username = Console.ReadLine()!;
        Console.Write("New password: ");
        string password = Console.ReadLine()!;

        bool ok = userService.Register(username, password);

        if (!ok)
            Console.WriteLine(" Username already exists!");
        else
            Console.WriteLine("  Successfully Registered!");
    }
    else if (input == "0")
    {
        return;
    }
    else
    {
        Console.WriteLine("Invalid option!");
    }
}

while (true)
{
    Console.WriteLine("\n+=={:::::::::::::::: MAIN MENU :::::::::::::::::::}==+");
    Console.WriteLine("                     1. Store");
    Console.WriteLine("                     2. Orders");
    Console.WriteLine("                     0. Exit");
    Console.Write("Choose option: ");

    string input = Console.ReadLine()!;

    if (input == "1")
    {
        Console.WriteLine("\n--- Store Products ---");
        foreach (var p in productService.GetAllProducts())
            Console.WriteLine(p);

        var customer = new Customer { Id = 1, FullName = loggedUser.Username };
        var orderProducts = new List<Product>();

        while (true)
        {
            Console.Write("\nEnter Product ID to add (0 to finish): ");
            string pidInput = Console.ReadLine()!;

            if (pidInput == "0") break;

            if (int.TryParse(pidInput, out int pid))
            {
                var product = productService.GetById(pid);
                if (product != null)
                {
                    orderProducts.Add(product);
                    Console.WriteLine($"{product.Name} added to order.");
                }
                else Console.WriteLine("Product not found.");
            }
            else Console.WriteLine("Invalid input!");
        }

        if (orderProducts.Count > 0)
        {
            var order = orderService.CreateOrder(customer, orderProducts);
            Console.WriteLine($"\nOrder #{order.Id} created!");
            Console.WriteLine($"Client: {order.Customer.FullName}");
            Console.WriteLine($"Total Price: {order.TotalPrice} GEL");
        }
        else Console.WriteLine("Order cancelled.");
    }
    else if (input == "2")
    {
        Console.WriteLine("\n--- All Orders ---");
        var orders = orderService.GetOrders();

        if (orders.Count == 0)
            Console.WriteLine("No orders found.");
        else
        {
            foreach (var order in orders)
            {
                Console.WriteLine($"\nOrder #{order.Id} - {order.Customer.FullName}");
                Console.WriteLine($"Created: {order.CreatedAt}");
                Console.WriteLine("Products:");
                foreach (var p in order.Products)
                    Console.WriteLine($"   - {p.Name} ({p.Price} GEL)");
                Console.WriteLine($"Total: {order.TotalPrice} GEL");
            }
        }
    }
    else if (input == "0")
    {
        Console.WriteLine("Goodbye!");
        break;
    }
    else
    {
        Console.WriteLine("Invalid option!");
    }
}
