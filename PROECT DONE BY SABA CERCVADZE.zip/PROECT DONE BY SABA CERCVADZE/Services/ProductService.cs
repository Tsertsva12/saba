﻿using ShopSystem.Models;

namespace ShopSystem.Services
{
    public class ProductService
    {
        private readonly List<Product> _products = new List<Product>();
        private int _nextId = 1;

        public Product AddProduct(string name, decimal price, int stock)
        {
            var product = new Product
            {
                Id = _nextId++,
                Name = name,
                Price = price,
                Stock = stock
            };

            _products.Add(product);
            return product;
        }

        public List<Product> GetAllProducts() => _products;

        public Product? GetById(int id) => _products.FirstOrDefault(p => p.Id == id);
    }
}
