﻿using ShopSystem.Models;

namespace ShopSystem.Services
{
    public class OrderService
    {
        private readonly List<Order> _orders = new List<Order>();
        private int _nextId = 1;

        public Order CreateOrder(Customer customer, List<Product> products)
        {
            var order = new Order
            {
                Id = _nextId++,
                Customer = customer,
                Products = products
            };

            _orders.Add(order);
            return order;
        }

        public List<Order> GetOrders() => _orders;
    }
}
